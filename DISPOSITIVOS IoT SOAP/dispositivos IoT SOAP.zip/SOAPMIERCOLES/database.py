from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

# URL de conexión a Railway (MySQL + PyMySQL)
DATABASE_URL = (
    "mysql+pymysql://root:mjyxNtZgdCjCKblDnyWSAuDmwmGAOvmD@metro.proxy.rlwy.net:30886/railway"
  
)

# Crear engine con echo=True para ver las consultas SQL en consola
engine = create_engine(DATABASE_URL, echo=True)

# Sesión para interactuar con la base de datos
SessionLocal = sessionmaker(bind=engine)

# Base que usarán los modelos ORM
Base = declarative_base()
