from wsgiref.simple_server import make_server
from server import application

if __name__ == "__main__":
    print("===========================================")
    print(" SERVIDOR SOAP corriendo en:")
    print("   → http://localhost:8000/?wsdl")
    print("===========================================")

    servidor = make_server("0.0.0.0", 8000, application)
    servidor.serve_forever()

