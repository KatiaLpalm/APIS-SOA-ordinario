from sqlalchemy import Column, Integer, String
from database import Base

class Dispositivo(Base):
    __tablename__ = "dispositivos"

    id = Column(Integer, primary_key=True, autoincrement=True)
    nombre = Column(String(100), nullable=False)
    tipo = Column(String(50), nullable=False)
    modelo = Column(String(50), nullable=False)
    serie = Column(String(100), nullable=False, unique=True)

    def __repr__(self):
        return (
            f"<Dispositivo(id={self.id}, nombre='{self.nombre}', "
            f"tipo='{self.tipo}', modelo='{self.modelo}', serie='{self.serie}')>"
        )
