package com.example.demo.Controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.Models.FrecuenciaCardiacaModel;
import com.example.demo.Models.UsuariosModel;
import com.example.demo.Service.FrecuenciaCardiacaService;
import com.example.demo.Service.UsuariosService;

@RestController
@RequestMapping("/api/frecuencias")
public class FrecuenciaCardiacaController {

    @Autowired
    private FrecuenciaCardiacaService frecuenciaService;

    @Autowired
    private UsuariosService usuariosService;

    // Obtener todos los registros
    @GetMapping
    public List<FrecuenciaCardiacaModel> getAll() {
        return frecuenciaService.getAllRegistros();
    }

    // Obtener registros por usuario
    @GetMapping("/usuario/{idUsuario}")
    public List<FrecuenciaCardiacaModel> getByUsuario(@PathVariable Long idUsuario) {
        return frecuenciaService.getRegistrosByUsuario(idUsuario);
    }

    // Obtener un registro por ID
    @GetMapping("/{id}")
    public ResponseEntity<FrecuenciaCardiacaModel> getById(@PathVariable Long id) {
        Optional<FrecuenciaCardiacaModel> registro = frecuenciaService.getRegistroById(id);
        return registro.isPresent()
                ? ResponseEntity.ok(registro.get())
                : ResponseEntity.notFound().build();
    }

    // Crear registro de frecuencia por usuario
    @PostMapping("/usuario/{idUsuario}")
    public ResponseEntity<FrecuenciaCardiacaModel> create(
            @PathVariable Long idUsuario,
            @RequestBody FrecuenciaCardiacaModel registro) {

        Optional<UsuariosModel> usuario = usuariosService.getUsuarioById(idUsuario);

        if (usuario.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        registro.setUsuario(usuario.get());
        FrecuenciaCardiacaModel saved = frecuenciaService.saveRegistro(registro);

        return ResponseEntity.ok(saved);
    }

    // Eliminar registro
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        frecuenciaService.deleteRegistro(id);
        return ResponseEntity.noContent().build();
    }
}
