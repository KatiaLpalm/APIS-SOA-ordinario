package com.example.demo.Models;

import java.time.LocalDateTime;

import jakarta.persistence.*;

@Entity
@Table(name = "frecuencias_cardiacas")
public class FrecuenciaCardiacaModel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_registro")
    private Long id;

    @ManyToOne
    @JoinColumn(name = "id_usuario", nullable = false)
    private UsuariosModel usuario;

    @Column(name = "fecha_hora", nullable = false)
    private LocalDateTime fechaHora;

    @Column(name = "bpm", nullable = false)
    private Integer bpm;

    public FrecuenciaCardiacaModel() {}

    public FrecuenciaCardiacaModel(UsuariosModel usuario, LocalDateTime fechaHora, Integer bpm) {
        this.usuario = usuario;
        this.fechaHora = fechaHora;
        this.bpm = bpm;
    }

    // Getters y setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public UsuariosModel getUsuario() {
        return usuario;
    }

    public void setUsuario(UsuariosModel usuario) {
        this.usuario = usuario;
    }

    public LocalDateTime getFechaHora() {
        return fechaHora;
    }

    public void setFechaHora(LocalDateTime fechaHora) {
        this.fechaHora = fechaHora;
    }

    public Integer getBpm() {
        return bpm;
    }

    public void setBpm(Integer bpm) {
        this.bpm = bpm;
    }
}
