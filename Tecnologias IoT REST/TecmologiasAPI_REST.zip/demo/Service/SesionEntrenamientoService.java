package com.example.demo.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Models.SesionEntrenamientoModel;
import com.example.demo.Repositories.ISesionEntrenamientoRepository;

@Service
public class SesionEntrenamientoService {

    @Autowired
    private ISesionEntrenamientoRepository repository;

    public List<SesionEntrenamientoModel> getAllSesiones() {
        return repository.findAll();
    }

    public List<SesionEntrenamientoModel> getSesionesByUsuario(Long usuarioId) {
        return repository.findByUsuarioId(usuarioId);
    }

    public Optional<SesionEntrenamientoModel> getSesionById(Long id) {
        return repository.findById(id);
    }

    public SesionEntrenamientoModel saveSesion(SesionEntrenamientoModel sesion) {
        return repository.save(sesion);
    }

    public void deleteSesion(Long id) {
        repository.deleteById(id);
    }
}
