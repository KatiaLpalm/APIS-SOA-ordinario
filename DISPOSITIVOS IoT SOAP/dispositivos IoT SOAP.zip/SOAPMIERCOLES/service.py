from database import SessionLocal
from frecuencia_cardiaca import FrecuenciaCardiaca
from models import Dispositivo
from resumen_actividad import ResumenActividad


class DispositivoService:

    # ====================================================
    # CRUD DISPOSITIVOS
    # ====================================================
    def registrar_dispositivo(self, nombre, tipo, modelo, serie):
        db = SessionLocal()
        try:
            dispositivo = Dispositivo(
                nombre=nombre,
                tipo=tipo,
                modelo=modelo,
                serie=serie
            )
            db.add(dispositivo)
            db.commit()
            db.refresh(dispositivo)
            return dispositivo
        finally:
            db.close()

    def listar_dispositivos(self):
        db = SessionLocal()
        try:
            return db.query(Dispositivo).all()
        finally:
            db.close()

    def obtener_por_id(self, id_dispositivo):
        db = SessionLocal()
        try:
            return db.query(Dispositivo).filter(Dispositivo.id == id_dispositivo).first()
        finally:
            db.close()

    def eliminar_dispositivo(self, id_dispositivo):
        db = SessionLocal()
        try:
            dispositivo = db.query(Dispositivo).filter(Dispositivo.id == id_dispositivo).first()
            if dispositivo:
                db.delete(dispositivo)
                db.commit()
                return True
            return False
        finally:
            db.close()

    # ====================================================
    # RESUMEN ACTIVIDAD
    # ====================================================
    def registrar_resumen_actividad(self, usuario_id, pasos, distancia_km, calorias_quemadas, fecha):
        db = SessionLocal()
        try:
            nuevo = ResumenActividad(
                id=ResumenActividad.generar_id(), 
                usuario_id=usuario_id,
                pasos=pasos,
                distancia_km=distancia_km,
                calorias_quemadas=calorias_quemadas,
                fecha=fecha
            )

            db.add(nuevo)
            db.commit()
            return nuevo

        except Exception as e:
            db.rollback()
            return f"Error: {str(e)}"

        finally:
            db.close()

 # ====================================================
    # FRECUENCIA CARDIACA
    # ====================================================
    def registrar_frecuencia_cardiaca(self, usuario_id, bpm, fecha_hora):
        db = SessionLocal()
        try:
            nuevo = FrecuenciaCardiaca(
                usuario_id=usuario_id,
                bpm=bpm,
                fecha_hora=fecha_hora
            )

            db.add(nuevo)
            db.commit()
            db.refresh(nuevo)
            return nuevo

        except Exception as e:
            db.rollback()
            return f"Error: {str(e)}"

        finally:
            db.close()