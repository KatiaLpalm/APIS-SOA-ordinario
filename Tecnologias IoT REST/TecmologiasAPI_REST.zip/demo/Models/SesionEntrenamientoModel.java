package com.example.demo.Models;
import java.time.LocalDate;

import jakarta.persistence.*;

@Entity
@Table(name = "sesiones_entrenamiento")
public class SesionEntrenamientoModel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_sesion")
    private Long id;

    @ManyToOne
    @JoinColumn(name = "id_usuario", nullable = false)
    private UsuariosModel usuario;

    @Column(name = "fecha", nullable = false)
    private LocalDate fecha;

    @Column(name = "tipo_entrenamiento", nullable = false, length = 100)
    private String tipoEntrenamiento;

    @Column(name = "duracion_minutos", nullable = false)
    private Integer duracionMinutos;

    @Column(name = "calorias_quemadas")
    private Integer caloriasQuemadas;

    public SesionEntrenamientoModel() {
    }

    public SesionEntrenamientoModel(UsuariosModel usuario, LocalDate fecha, String tipoEntrenamiento,
            Integer duracionMinutos, Integer caloriasQuemadas) {
        this.usuario = usuario;
        this.fecha = fecha;
        this.tipoEntrenamiento = tipoEntrenamiento;
        this.duracionMinutos = duracionMinutos;
        this.caloriasQuemadas = caloriasQuemadas;
    }

    // Getters y Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public UsuariosModel getUsuario() {
        return usuario;
    }

    public void setUsuario(UsuariosModel usuario) {
        this.usuario = usuario;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public String getTipoEntrenamiento() {
        return tipoEntrenamiento;
    }

    public void setTipoEntrenamiento(String tipoEntrenamiento) {
        this.tipoEntrenamiento = tipoEntrenamiento;
    }

    public Integer getDuracionMinutos() {
        return duracionMinutos;
    }

    public void setDuracionMinutos(Integer duracionMinutos) {
        this.duracionMinutos = duracionMinutos;
    }

    public Integer getCaloriasQuemadas() {
        return caloriasQuemadas;
    }

    public void setCaloriasQuemadas(Integer caloriasQuemadas) {
        this.caloriasQuemadas = caloriasQuemadas;
    }
}
