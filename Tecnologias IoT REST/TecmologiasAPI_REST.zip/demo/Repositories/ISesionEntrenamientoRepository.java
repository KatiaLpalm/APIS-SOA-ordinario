package com.example.demo.Repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.Models.SesionEntrenamientoModel;

@Repository
public interface ISesionEntrenamientoRepository extends JpaRepository<SesionEntrenamientoModel, Long> {

    List<SesionEntrenamientoModel> findByUsuarioId(Long usuarioId);
}
