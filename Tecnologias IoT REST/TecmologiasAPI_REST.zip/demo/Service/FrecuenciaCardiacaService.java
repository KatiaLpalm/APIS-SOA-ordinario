package com.example.demo.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Models.FrecuenciaCardiacaModel;
import com.example.demo.Repositories.IFrecuenciaCardiacaRepository;

@Service
public class FrecuenciaCardiacaService {

    @Autowired
    private IFrecuenciaCardiacaRepository repository;

    public List<FrecuenciaCardiacaModel> getAllRegistros() {
        return repository.findAll();
    }

    // Filtrado manual por usuario
    public List<FrecuenciaCardiacaModel> getRegistrosByUsuario(Long usuarioId) {
        return repository.findAll()
                .stream()
                .filter(r -> r.getUsuario().getId().equals(usuarioId))
                .collect(Collectors.toList());
    }

    public Optional<FrecuenciaCardiacaModel> getRegistroById(Long id) {
        return repository.findById(id);
    }

    public FrecuenciaCardiacaModel saveRegistro(FrecuenciaCardiacaModel registro) {
        return repository.save(registro);
    }

    public void deleteRegistro(Long id) {
        repository.deleteById(id);
    }
}
