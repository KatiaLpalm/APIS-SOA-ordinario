from sqlalchemy import Column, Integer, Numeric, Date
from database import Base
from sqlalchemy.orm import Session
from database import SessionLocal

class ResumenActividad(Base):
    __tablename__ = "resumen_actividad"

    id = Column(Integer, primary_key=True)  # ❗ quita autoincrement=True
    usuario_id = Column(Integer, nullable=False)
    pasos = Column(Integer, nullable=False)
    distancia_km = Column(Numeric(10, 2), nullable=False)
    calorias_quemadas = Column(Integer, nullable=False)
    fecha = Column(Date, nullable=False)

    @staticmethod
    def generar_id():
        db = SessionLocal()
        ultimo = db.query(ResumenActividad).order_by(ResumenActividad.id.desc()).first()
        db.close()
        return 1 if ultimo is None else ultimo.id + 1
