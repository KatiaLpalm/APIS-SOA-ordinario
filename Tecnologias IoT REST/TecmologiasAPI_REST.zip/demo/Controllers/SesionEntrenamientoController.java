package com.example.demo.Controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.Models.SesionEntrenamientoModel;
import com.example.demo.Models.UsuariosModel;
import com.example.demo.Service.SesionEntrenamientoService;
import com.example.demo.Service.UsuariosService;

@RestController
@RequestMapping("/api/sesiones")
public class SesionEntrenamientoController {

    @Autowired
    private SesionEntrenamientoService sesionService;

    @Autowired
    private UsuariosService usuariosService;

    // Todas las sesiones
    @GetMapping
    public List<SesionEntrenamientoModel> getAll() {
        return sesionService.getAllSesiones();
    }

    // Sesiones por usuario
    @GetMapping("/usuario/{idUsuario}")
    public List<SesionEntrenamientoModel> getByUsuario(@PathVariable Long idUsuario) {
        return sesionService.getSesionesByUsuario(idUsuario);
    }

    // Obtener sesión por ID
    @GetMapping("/{id}")
    public ResponseEntity<SesionEntrenamientoModel> getById(@PathVariable Long id) {
        Optional<SesionEntrenamientoModel> sesion = sesionService.getSesionById(id);
        return sesion.isPresent()
                ? ResponseEntity.ok(sesion.get())
                : ResponseEntity.notFound().build();
    }

    // Crear sesión de entrenamiento
    @PostMapping("/usuario/{idUsuario}")
    public ResponseEntity<SesionEntrenamientoModel> create(
            @PathVariable Long idUsuario,
            @RequestBody SesionEntrenamientoModel sesion) {

        Optional<UsuariosModel> usuario = usuariosService.getUsuarioById(idUsuario);

        if (usuario.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        sesion.setUsuario(usuario.get());
        SesionEntrenamientoModel saved = sesionService.saveSesion(sesion);

        return ResponseEntity.ok(saved);
    }

    // Eliminar sesión
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        sesionService.deleteSesion(id);
        return ResponseEntity.noContent().build();
    }
}
