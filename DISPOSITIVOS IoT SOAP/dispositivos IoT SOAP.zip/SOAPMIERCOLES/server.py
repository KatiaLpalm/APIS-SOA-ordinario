from spyne import Application, rpc, ServiceBase, Unicode, Integer, Float, Date
from spyne.protocol.soap import Soap11
from spyne.server.wsgi import WsgiApplication
from sqlalchemy import DateTime
from service import DispositivoService


class DispositivoSOAP(ServiceBase):

    # ========================================
    #   REGISTRAR DISPOSITIVO
    # ========================================
    @rpc(Unicode, Unicode, Unicode, Unicode, _returns=Unicode)
    def registrar_dispositivo(ctx, nombre, tipo, modelo, serie):
        servicio = DispositivoService()
        dispositivo = servicio.registrar_dispositivo(nombre, tipo, modelo, serie)
        return f"Dispositivo registrado con ID {dispositivo.id}"

    # ========================================
    #   LISTAR DISPOSITIVOS
    # ========================================
    @rpc(_returns=Unicode)
    def listar_dispositivos(ctx):
        servicio = DispositivoService()
        dispositivos = servicio.listar_dispositivos()

        salida = ""
        for d in dispositivos:
            salida += f"[{d.id}] {d.nombre} - {d.tipo} - {d.modelo} - {d.serie}\n"

        return salida if salida else "No hay dispositivos registrados."

    # ========================================
    #   REGISTRAR RESUMEN ACTIVIDAD
    # ========================================
    @rpc(Integer, Integer, Float, Integer, Date, _returns=Unicode)
    def registrar_resumen_actividad(ctx, usuario_id, pasos, distancia_km, calorias_quemadas, fecha):
        servicio = DispositivoService()
        resultado = servicio.registrar_resumen_actividad(
            usuario_id,
            pasos,
            distancia_km,
            calorias_quemadas,
            fecha
        )

        if isinstance(resultado, str):
            return resultado  # si hubo error

        return f"Resumen registrado con ID {resultado.id}"

 # ========================================
    #   REGISTRAR FRECUENCIA CARDIACA
    # ========================================
    @rpc(Integer, Integer, DateTime, _returns=Unicode)
    def registrar_frecuencia_cardiaca(ctx, usuario_id, bpm, fecha_hora):
        servicio = DispositivoService()

        resultado = servicio.registrar_frecuencia_cardiaca(
            usuario_id=usuario_id,
            bpm=bpm,
            fecha_hora=fecha_hora
        )

        if isinstance(resultado, str):
            return resultado  # si hubo error

        return f"Frecuencia cardiaca registrada con ID {resultado.id}"
# ============================================
#   SOAP APPLICATION
# ============================================
soap_app = Application(
    [DispositivoSOAP],
    "tecnologias.iot.soap",
    in_protocol=Soap11(validator="lxml"),
    out_protocol=Soap11()
)

application = WsgiApplication(soap_app)
