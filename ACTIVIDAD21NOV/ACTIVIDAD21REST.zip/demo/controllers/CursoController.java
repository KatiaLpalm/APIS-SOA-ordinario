package com.example.demo.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.models.Curso;
import com.example.demo.service.CursoService;



@RestController
@RequestMapping("/cursos")
public class CursoController {

    @Autowired
    private CursoService cursoService;

    // Get all cursos
    @GetMapping
    public List<Curso> getAllCursos() {
        return cursoService.getAllCursos();
    }

    // Get curso by id
    @GetMapping("/{id}")
    public ResponseEntity<Curso> getCursoById(@PathVariable Long id) {
        Optional<Curso> curso = cursoService.getCursoById(id);
        return curso.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Create curso
    @PostMapping
    public Curso createCurso(@RequestBody Curso curso) {
        return cursoService.saveCurso(curso);
    }

    // Update curso
    @PutMapping("/{id}")
    public ResponseEntity<Curso> updateCurso(@PathVariable Long id, @RequestBody Curso cursoDetails) {
        Optional<Curso> cursoOptional = cursoService.getCursoById(id);

        if (cursoOptional.isPresent()) {
            Curso cursoToUpdate = cursoOptional.get();

            cursoToUpdate.setNombre(cursoDetails.getNombre());
            cursoToUpdate.setDescripcion(cursoDetails.getDescripcion());
            cursoToUpdate.setCreditos(cursoDetails.getCreditos());
            cursoToUpdate.setEstado(cursoDetails.getEstado());

            Curso updatedCurso = cursoService.saveCurso(cursoToUpdate);
            return ResponseEntity.ok(updatedCurso);

        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Delete curso
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCurso(@PathVariable Long id) {
        Optional<Curso> curso = cursoService.getCursoById(id);

        if (curso.isPresent()) {
            cursoService.deleteCurso(id);
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
