from sqlalchemy import Column, Integer, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from database import Base
from datetime import datetime

class FrecuenciaCardiaca(Base):
    __tablename__ = "frecuencia_cardiaca"

    id = Column(Integer, primary_key=True, autoincrement=True)
    usuario_id = Column(Integer, ForeignKey("usuarios.id"), nullable=False)
    bpm = Column(Integer, nullable=False)
    fecha_hora = Column(DateTime, default=datetime.utcnow)

    usuario = relationship("Usuario")
